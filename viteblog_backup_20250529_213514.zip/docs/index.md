---
# https://vitepress.dev/reference/default-theme-home-page
layout: home

hero:
  name: "ZhonXu 的个人博客"
  text: "基于 Vitepress"
  tagline: Given enough eyeballs,all bugs are shallow.
  actions:
    - theme: brand
      text: 提问的智慧
      link: /how-to-ask-a-question
    - theme: alt
      text: 新人上手 Koishi
      link: /koishi-guide


